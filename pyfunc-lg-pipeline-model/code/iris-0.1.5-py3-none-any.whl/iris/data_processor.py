"""DataProcessor module."""

import pandas as pd
from loguru import logger
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, to_utc_timestamp
from sklearn.model_selection import train_test_split

from iris.config import ProjectConfig

spark = SparkSession.builder.getOrCreate()


class DataProcessor:
    """A class for preprocessing and managing DataFrame operations.

    This class handles data preprocessing, splitting, and saving to Databricks tables.
    """

    def __init__(self, pandas_df: pd.DataFrame, config: ProjectConfig) -> None:
        self.df = pandas_df  # Store the DataFrame as self.df
        self.config = config  # Store the configuration

    def _apply_value_correction(self, correction: dict) -> None:
        """Apply value corrections to the DataFrame based on the provided dictionary.

        :param correction: A dictionary containing the corrections to be applied.
        """
        for column, values in correction.items():
            for old_value, new_value in values.items():
                self.df.loc[self.df[column] == old_value, column] = new_value

        logger.info("Value corrections applied successfully")

    def preprocess(self) -> None:
        """Preprocess the DataFrame stored in self.df.

        This method handles missing values, converts data types, and performs feature engineering.
        """
        # Handle numeric features
        for col in self.config.num_features:
            self.df[col] = pd.to_numeric(self.df[col], errors="coerce")
        logger.info("Numeric features are converted to 'numeric' data type")

        # map the labels to numeric values
        corrections = {"Species": {"Iris-setosa": 0, "Iris-versicolor": 1, "Iris-virginica": 2}}
        self._apply_value_correction(corrections)

        # Extract target and relevant features
        relevant_columns = ["Id"] + self.config.num_features + [self.config.target]
        self.df = self.df[relevant_columns]
        self.df["Id"] = self.df["Id"].astype("str")
        logger.info("Preprocessing is completed!")

    def split_data(self, test_size: float = 0.2, random_state: int = 42) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Split the DataFrame (self.df) into training and test sets.

        :param test_size: The proportion of the dataset to include in the test split.
        :param random_state: Controls the shuffling applied to the data before applying the split.
        :return: A tuple containing the training and test DataFrames.
        """
        train_set, test_set = train_test_split(self.df, test_size=test_size, random_state=random_state)
        return train_set, test_set

        logger.info("Data is split into training and test sets.")

    # def save_to_disk(self, train_set: pd.DataFrame, test_set: pd.DataFrame) -> None:
    #     """Save the train and test sets into local disk.

    #     :param train_set: The training DataFrame to be saved.
    #     :param test_set: The test DataFrame to be saved.
    #     """
    #     # Create directory if needed (with parents if in nested path)
    #     DATA_DIR.mkdir(parents=True, exist_ok=True)
    #     train_set.to_csv(f"{DATA_DIR}/train_set.csv", index=False)
    #     test_set.to_csv(f"{DATA_DIR}/test_set.csv", index=False)
    #     logger.info("Train_set and test_set are save to local disk")

    def save_to_catalog(self, train_set: pd.DataFrame, test_set: pd.DataFrame) -> None:
        """Save the train and test sets into Databricks tables.

        :param train_set: The training DataFrame to be saved.
        :param test_set: The test DataFrame to be saved.
        """
        train_set_with_timestamp = spark.createDataFrame(train_set).withColumn(
            "update_timestamp_utc", to_utc_timestamp(current_timestamp(), "UTC")
        )

        test_set_with_timestamp = spark.createDataFrame(test_set).withColumn(
            "update_timestamp_utc", to_utc_timestamp(current_timestamp(), "UTC")
        )

        train_set_with_timestamp.write.mode("append").saveAsTable(
            f"{self.config.catalog_name}.{self.config.schema_name}.train_set"
        )

        test_set_with_timestamp.write.mode("append").saveAsTable(
            f"{self.config.catalog_name}.{self.config.schema_name}.test_set"
        )

        spark.sql(
            f"ALTER TABLE {self.config.catalog_name}.{self.config.schema_name}.train_set SET TBLPROPERTIES (delta.enableChangeDataFeed = true);"
        )

        spark.sql(
            f"ALTER TABLE {self.config.catalog_name}.{self.config.schema_name}.test_set SET TBLPROPERTIES (delta.enableChangeDataFeed = true);"
        )

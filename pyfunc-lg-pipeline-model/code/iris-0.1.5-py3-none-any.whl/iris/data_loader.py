"""DataLoader module."""

from abc import ABC, abstractmethod

import pandas as pd
from loguru import logger


class DataLoader(ABC):
    """Abstract base class for data loaders.

    This class defines the blueprint for any data loader that must implement the `load` method.
    """

    @abstractmethod
    def load(self) -> pd.DataFrame:
        """Abstract method to load data.

        Subclasses must implement this method to provide functionality for loading data.
        """
        pass


class CSVLoader(DataLoader):
    """A loader class for reading CSV files into a Pandas DataFrame.

    This class provides functionality to load data from a CSV file and log the shape of the loaded DataFrame.
    """

    def __init__(self, file_name: str) -> None:
        """Initialize the CSVLoader with the file name.

        :param file_name: The path to the CSV file to be loaded.
        """
        self.file_name = file_name

    def load(self) -> pd.DataFrame:
        """Load the CSV file into a Pandas DataFrame.

        :return: A Pandas DataFrame containing the data from the CSV file.
        """
        pdf = pd.read_csv(filepath_or_buffer=self.file_name, header="infer")
        logger.info(f"Data loaded from local successfully with shape: {pdf.shape}")
        return pdf

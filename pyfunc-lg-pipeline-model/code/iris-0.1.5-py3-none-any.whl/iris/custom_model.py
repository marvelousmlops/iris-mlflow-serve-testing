"""Training module."""

from typing import Union

import mlflow
import numpy as np
import pandas as pd
from loguru import logger
from mlflow import MlflowClient
from mlflow.models import infer_signature
from mlflow.utils.environment import _mlflow_conda_env
from pyspark.sql import SparkSession
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from iris.config import ProjectConfig, Tags

spark = SparkSession.builder.getOrCreate()


class ModelWrapper(mlflow.pyfunc.PythonModel):
    """A wrapper class for machine learning models to be used with MLflow.

    This class encapsulates a model and provides a standardized predict method.
    """

    def __init__(self, model: object) -> None:
        self.model = model
        self.class_names = ["setosa", "versicolor", "virginica"]

    def predict(
        self,
        context: mlflow.pyfunc.PythonModelContext,
        model_input: Union[pd.DataFrame, np.array],  # noqa
    ) -> Union[pd.DataFrame, np.ndarray]:  # noqa
        """Perform predictions using the wrapped model.

        :param context: The MLflow PythonModelContext, which provides runtime information.
        :param model_input: The input data for prediction, either as a pandas DataFrame or a NumPy array.
        :return: redictions mapped to class names in original input format.
        """
        raw_predictions = self.model.predict(model_input)
        # logger.info(f"Raw predictions: {raw_predictions}") # noqa
        mapped_predictions = [self.class_names[int(pred)] for pred in raw_predictions]
        # logger.info(f"Mapped predictions: {mapped_predictions}") # noqa
        return mapped_predictions


class CustomModel:
    """A custom machine learning model class.

    The class handles data loading, preprocessing,training, logging to MLflow, and model registration.
    """

    def __init__(self, config: ProjectConfig, tags: Tags, code_paths: list[str]) -> None:
        self.config = config
        self.catalog_name=config.catalog_name
        self.schema_name = config.schema_name
        self.tags = tags.model_dump()
        self.code_paths = code_paths

        # disable autologging in order not to have multiple experiments and runs :)
        mlflow.autolog(disable=True)

    def load_data(self) -> None:
        """Load training and testing datasets from predefined paths.

        This method initializes attributes for training and testing features and targets.
        """
        # self.train_set = pd.read_csv(f"{DATA_DIR}/train_set.csv")
        # self.test_set = pd.read_csv(f"{DATA_DIR}/test_set.csv")

        logger.info("🔄 Loading data from Databricks tables...")
        self.train_set_spark = spark.table(f"{self.catalog_name}.{self.schema_name}.train_set")
        self.train_set = self.train_set_spark.toPandas()
        self.test_set = spark.table(f"{self.catalog_name}.{self.schema_name}.test_set").toPandas()
        self.data_version = "0"  # describe history -> retrieve

        self.X_train = self.train_set[self.config.num_features]
        self.y_train = self.train_set[self.config.target]
        self.X_test = self.test_set[self.config.num_features]
        self.y_test = self.test_set[self.config.target]
        logger.info("✅ Data successfully loaded.")

    def prepare_features(self) -> None:
        """Define preprocessing pipeline for feature scaling and model training.

        This method sets up a pipeline combining preprocessing steps and a logistic regression classifier.
        """
        try:
            logger.info("🔄 Defining preprocessing pipeline...")
            self.preprocessor = ColumnTransformer(
                transformers=[("std_scaler", StandardScaler(), self.config.num_features)]
            )

            # Create a pipeline with preprocessing and logistic regression classifier
            self.pipeline = Pipeline(
                steps=[
                    ("preprocessor", self.preprocessor),  # Preprocessing step
                    ("classifier", LogisticRegression(**self.config.parameters)),  # Classification step
                ]
            )

            logger.info("✅ Preprocessing pipeline defined.")
        except Exception as err:
            logger.error(f"❌ Failed to define preprocessing pipeline: {err}")
            raise

    def train(self) -> None:
        """Train the model using the prepared pipeline.

        This method fits the pipeline to the training data.
        """
        logger.info("🚀 Starting training...")
        self.pipeline.fit(self.X_train, self.y_train)

    def log_model(self) -> None:
        """Log the trained model and its metrics to MLflow.

        This method evaluates the model, logs parameters and metrics, and saves the model in MLflow.
        """
        mlflow.set_experiment(self.config.experiment_name)

        additional_pip_deps = ["pyspark==3.5.0"] # noqa
        # additional_pip_deps = []
        for package in self.code_paths:
            whl_name = package.split("/")[-1]
            additional_pip_deps.append(f"./code/{whl_name}")

        with mlflow.start_run(tags=self.tags) as run:
            self.run_id = run.info.run_id
            y_pred = self.pipeline.predict(self.X_test)
            y_proba = self.pipeline.predict_proba(self.X_test)

            # Evaluation metrics
            accuracy = accuracy_score(self.y_test, y_pred)
            auc_test = roc_auc_score(self.y_test, y_proba, multi_class="ovr")
            clf_report = classification_report(self.y_test, y_pred)

            logger.info(f"Accuracy Report: {accuracy}")
            logger.info(f"AUC      Report: {auc_test}")
            logger.info(f"Classification Report: \n{clf_report}")

            # Log parameters and metrics
            mlflow.log_param("model_type", "LogisticRegression Classifier with preprocessing")
            mlflow.log_params(self.config.parameters)
            mlflow.log_metric("accuracy", accuracy)
            mlflow.log_metric("auc", auc_test)

            # Log the model
            signature = infer_signature(model_input=self.X_train, model_output=self.pipeline.predict(self.X_train))
            dataset = mlflow.data.from_pandas(
                self.train_set,
                name="train_set",
            )

            mlflow.log_input(dataset, context="training")

            conda_env = _mlflow_conda_env(additional_pip_deps=additional_pip_deps)

            mlflow.pyfunc.log_model(
                python_model=ModelWrapper(self.pipeline),
                artifact_path=f"pyfunc-{self.config.model.artifact_path}",
                code_paths=self.code_paths,
                conda_env=conda_env,
                signature=signature,
            )

    def register_model(self) -> None:
        """Register the trained model in MLflow Model Registry.

        This method registers the model and sets an alias for the latest version.
        """
        logger.info("🔄 Registering the model ...")
        registered_model = mlflow.register_model(
            model_uri=f"runs:/{self.run_id}/pyfunc-{self.config.model.artifact_path}",
            name=f"{self.catalog_name}.{self.schema_name}.{self.config.model.name}",
            tags=self.tags,
        )
        logger.info(f"✅ Model registered as version {registered_model.version}.")

        latest_version = registered_model.version

        client = MlflowClient()
        client.set_registered_model_alias(
            name=f"{self.catalog_name}.{self.schema_name}.{self.config.model.name}",
            alias="latest-model",
            version=latest_version,
        )

    def load_latest_model_and_predict(self, input_data: pd.DataFrame) -> np.ndarray:
        """Load the latest model (alias=latest-model) from MLflow and make predictions.

        Alias latest is not allowed -> we use latest-model instead as an alternative.

        :param input_data: Input data for prediction.
        :return: Predictions.

        Note:
        This also works
        model.unwrap_python_model().predict(None, input_data)
        check out this article:
        https://medium.com/towards-data-science/algorithm-agnostic-model-building-with-mlflow-b106a5a29535

        """
        logger.info("🔄 Loading model from MLflow alias 'production'...")

        model_uri = f"models:/{self.catalog_name}.{self.schema_name}.{self.config.model.name}@latest-model"
        model = mlflow.pyfunc.load_model(model_uri)

        logger.info("✅ Model successfully loaded.")

        # Make predictions: None is context
        predictions = model.predict(input_data)

        # Return predictions as a DataFrame
        return predictions
